  <!-- JavaScript for interactivity -->
    <script>
        // Get current year for footer
        document.getElementById('current-year').textContent = new Date().getFullYear();

        // Mobile menu toggle
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const mobileMenu = document.getElementById('mobile-menu');
        const menuIconClosed = document.getElementById('menu-icon-closed');
        const menuIconOpen = document.getElementById('menu-icon-open');

        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('open');
            menuIconClosed.classList.toggle('hidden');
            menuIconOpen.classList.toggle('hidden');
        });

        // Close mobile menu when a nav item is clicked
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', () => {
                if (mobileMenu.classList.contains('open')) {
                    mobileMenu.classList.remove('open');
                    menuIconClosed.classList.remove('hidden');
                    menuIconOpen.classList.add('hidden');
                }
            });
        });

        // Highlight active section in navigation
        const sections = document.querySelectorAll('section');
        const navLinks = document.querySelectorAll('.nav-item');

        const highlightActiveNavLink = () => {
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop - 100; // Adjust for fixed nav height
                const sectionHeight = section.clientHeight;
                if (pageYOffset >= sectionTop && pageYOffset < sectionTop + sectionHeight) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('bg-indigo-600', 'text-white', 'shadow-lg');
                link.classList.add('text-gray-700', 'hover:bg-indigo-50', 'hover:text-indigo-600');
                if (link.href.includes(current)) {
                    link.classList.add('bg-indigo-600', 'text-white', 'shadow-lg');
                    link.classList.remove('text-gray-700', 'hover:bg-indigo-50', 'hover:text-indigo-600');
                }
            });
        };

        window.addEventListener('scroll', highlightActiveNavLink);
        window.addEventListener('load', highlightActiveNavLink); // Highlight on page load

        // Handle contact form submission (client-side only for this demo)
        const contactForm = document.getElementById('contact-form');
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault(); // Prevent default form submission

            // In a real application, you would send this data to a backend server.
            // For this demo, we'll just show a custom message.
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;

            // Simple custom alert/message box logic
            const messageBox = document.createElement('div');
            messageBox.className = 'fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-[9999]';
            messageBox.innerHTML = `
                <div class="bg-white p-8 rounded-lg shadow-xl max-w-sm text-center">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">Pesan Terkirim!</h3>
                    <p class="text-gray-600 mb-6">Terima kasih, ${name}! Pesan Anda telah diterima. Saya akan segera menghubungi Anda.</p>
                    <button id="close-message-box" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-full transition-colors duration-300">Tutup</button>
                </div>
            `;
            document.body.appendChild(messageBox);

            document.getElementById('close-message-box').addEventListener('click', () => {
                document.body.removeChild(messageBox);
                contactForm.reset(); // Clear the form after closing the message
            });
        });
    </script>
</body>
</html>
